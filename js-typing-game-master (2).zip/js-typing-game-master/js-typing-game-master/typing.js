const WORDS = `
in one good real one not school set they state high life consider
on and not come what also for set point can want as while with of
order child about school thing never hold find each too between
program work end you home place around while place problem end begin
interest public where see time those increase give think seem small
`.trim().split(/\s+/);

let gameTime = 30;
let timer = null;
let startTime = null;
let correctChars = 0;
let typedChars = 0;

const game = document.getElementById('game');
const wordsEl = document.getElementById('words');
const infoEl = document.getElementById('info');
const cursor = document.getElementById('cursor');

let wordIndex = 0;
let letterIndex = 0;

function randomWord() {
  return WORDS[Math.floor(Math.random() * WORDS.length)];
}

function buildWords() {
  wordsEl.innerHTML = '';
  wordsEl.style.marginTop = '0px';

  for (let i = 0; i < 200; i++) {
    const word = document.createElement('div');
    word.className = 'word';

    randomWord().split('').forEach(ch => {
      const span = document.createElement('span');
      span.className = 'letter';
      span.textContent = ch;
      word.appendChild(span);
    });

    wordsEl.appendChild(word);
  }

  wordIndex = 0;
  letterIndex = 0;
  updateCurrent();
  updateCursor();
}

function updateCurrent() {
  document.querySelectorAll('.current').forEach(el =>
    el.classList.remove('current')
  );

  const word = wordsEl.children[wordIndex];
  const letter = word?.children[letterIndex];
  if (word) word.classList.add('current');
  if (letter) letter.classList.add('current');
}

function startTimer() {
  if (timer) return;

  startTime = Date.now();
  timer = setInterval(() => {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    const left = Math.max(0, gameTime - elapsed);
    infoEl.textContent = left;
    if (left === 0) endGame();
  }, 1000);
}

function endGame() {
  clearInterval(timer);
  timer = null;
  game.classList.add('over');

  const minutes = gameTime / 60;
  const wpm = Math.round((correctChars / 5) / minutes);
  const accuracy = typedChars
    ? Math.round((correctChars / typedChars) * 100)
    : 0;

  infoEl.textContent = `WPM ${wpm} | ${accuracy}%`;
}

game.addEventListener('keydown', e => {
  if (game.classList.contains('over')) return;

  const word = wordsEl.children[wordIndex];
  const letters = word?.children;
  if (!letters) return;

  if (e.key.length === 1 && e.key !== ' ') {
    startTimer();
    if (letterIndex < letters.length) {
      const letter = letters[letterIndex];
      const correct = e.key === letter.textContent;
      letter.classList.add(correct ? 'correct' : 'incorrect');
      typedChars++;
      if (correct) correctChars++;
      letterIndex++;
      updateCurrent();
      updateCursor();
    }
  }

  if (e.key === 'Backspace') {
    if (letterIndex === 0) return;
    letterIndex--;
    const letter = letters[letterIndex];
    if (letter.classList.contains('correct')) correctChars--;
    letter.classList.remove('correct', 'incorrect');
    typedChars = Math.max(0, typedChars - 1);
    updateCurrent();
    updateCursor();
  }

  if (e.key === ' ') {
    if (letterIndex < letters.length) return;
    wordIndex++;
    letterIndex = 0;
    updateCurrent();
    updateCursor();
    e.preventDefault();
  }
});

function updateCursor() {
  const word = wordsEl.children[wordIndex];
  const letter = word?.children[letterIndex] || word?.lastChild;
  if (!letter) return;

  const rect = letter.getBoundingClientRect();
  const gameRect = game.getBoundingClientRect();

  cursor.style.top = rect.top - gameRect.top + 'px';
  cursor.style.left =
    (letter === word.children[letterIndex]
      ? rect.left
      : rect.right) - gameRect.left + 'px';

  if (rect.top - gameRect.top > 70) {
    wordsEl.style.marginTop =
      (parseInt(wordsEl.style.marginTop || 0) - 36) + 'px';
  }
}

document.getElementById('newGameBtn').onclick = resetGame;

document.querySelectorAll('[data-time]').forEach(btn => {
  btn.onclick = () => {
    gameTime = Number(btn.dataset.time);
    resetGame();
  };
});

function resetGame() {
  clearInterval(timer);
  timer = null;
  startTime = null;
  correctChars = 0;
  typedChars = 0;
  game.classList.remove('over');
  infoEl.textContent = gameTime;
  buildWords();
  game.focus();
}

buildWords();
game.focus();
